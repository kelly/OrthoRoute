#!/usr/bin/env python3
"""
Simple IPC Test Plugin - KiCad 9.0+ IPC API Test (Clean Version)
Tests basic KiCad IPC API connection and creates one test track
"""

import os
import sys
import time
import traceback

def log_message(message):
    """Log messages with timestamp"""
    timestamp = time.strftime("%H:%M:%S")
    print(f"[{timestamp}] {message}")

# Import KiCad IPC API
try:
    from kipy import KiCad
    from kipy.board_types import Track
    from kipy.util.units import to_mm, from_mm
    from kipy.geometry import Vector2
    IPC_AVAILABLE = True
    log_message("[OK] KiCad IPC API (kipy) imported successfully")
except ImportError as e:
    log_message(f"[ERROR] Failed to import KiCad IPC API: {e}")
    log_message("Please install: pip install kicad-python")
    IPC_AVAILABLE = False

class SimpleIPCTestPlugin:
    """Simple IPC Test Plugin Class - KiCad 9.0+ Style"""
    
    def __init__(self):
        """Initialize the plugin"""
        self.kicad = None
        self.board = None
        
    def run(self):
        """Main plugin execution method"""
        try:
            log_message("[START] Simple IPC Test Plugin Starting...")
            
            if not IPC_AVAILABLE:
                log_message("[ERROR] KiCad IPC API not available")
                return 1
                
            # Connect to KiCad
            log_message("[CONNECT] Connecting to KiCad...")
            self.kicad = KiCad()
            
            # Get the active board
            log_message("[BOARD] Getting active board...")
            self.board = self.kicad.get_board()
            if not self.board:
                log_message("[ERROR] No active board found")
                return 1
                
            # Get board info
            try:
                dimensions = self.board.get_dimensions()
                log_message(f"[INFO] Board: {self.board.name}")
                log_message(f"[INFO] Board dimensions available: {len(dimensions) if dimensions else 0} dimension objects")
            except Exception as e:
                log_message(f"[WARN] Could not get board dimensions: {e}")
            
            # Create a simple test track
            log_message("[TRACK] Creating test track...")
            
            try:
                # Begin a commit transaction
                commit = self.board.begin_commit()
                
                # Create track using Track object
                track = Track()
                track.start = Vector2.from_xy_mm(10, 10)  # 10mm, 10mm
                track.end = Vector2.from_xy_mm(30, 10)    # 30mm, 10mm
                track.width = from_mm(0.2)                # 0.2mm width
                track.layer = 0                       # Front copper layer (F.Cu)
                
                result = self.board.create_items([track])
                
                # Commit the changes
                self.board.push_commit(commit)
                
                log_message("[OK] Test track created successfully!")
                
            except Exception as e:
                log_message(f"[ERROR] Failed to create track: {e}")
                import traceback
                traceback.print_exc()
                # Try to drop the commit if it failed
                try:
                    self.board.drop_commit()
                except:
                    pass
            
            log_message("[OK] Test track created successfully!")
            log_message("[SUCCESS] Simple IPC Test completed successfully!")
            
            return 0
            
        except Exception as e:
            log_message(f"[ERROR] Error in Simple IPC Test: {e}")
            traceback.print_exc()
            return 1

# IPC Plugin Pattern - Direct instantiation and execution
if __name__ == "__main__":
    try:
        plugin = SimpleIPCTestPlugin()
        exit_code = plugin.run()
        log_message(f"[FINISH] Test finished with exit code: {exit_code}")
        # Don't call sys.exit() - this can kill KiCad if run in plugin context
    except Exception as e:
        log_message(f"[FATAL] Fatal error in Simple IPC Test Plugin: {e}")
        traceback.print_exc()
        # Don't call sys.exit() - this can kill KiCad
