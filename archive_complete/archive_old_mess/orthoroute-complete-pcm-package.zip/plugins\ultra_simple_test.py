#!/usr/bin/env python3
"""
Ultra Simple Test - Proper Action Plugin
"""

import time
import os

# Log to a file so we can see if KiCad is even trying to load this
log_file = os.path.join(os.path.expanduser("~"), "kicad_plugin_test.log")

def log_message(message):
    """Helper function to log messages"""
    try:
        with open(log_file, "a") as f:
            timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
            f.write(f"[{timestamp}] {message}\n")
            f.flush()
    except Exception as e:
        print(f"Logging error: {e}")

try:
    import pcbnew
    log_message("pcbnew imported successfully")
    
    class UltraSimpleTestPlugin(pcbnew.ActionPlugin):
        def defaults(self):
            """Required method to define plugin properties"""
            self.name = "Ultra Simple Test"
            self.category = "Testing"
            self.description = "Ultra simple test to verify plugin loading"
            self.show_toolbar_button = True
            self.icon_file_name = "icon.png"
            log_message("Plugin defaults() called")
        
        def Run(self):
            """Method called when plugin is executed"""
            log_message("Plugin Run() method executed!")
            
            # Show a simple message
            import wx
            wx.MessageBox("Ultra Simple Test Plugin executed successfully!", 
                         "Success", wx.OK | wx.ICON_INFORMATION)
            
            log_message("Plugin execution completed")
    
    # Register the plugin
    UltraSimpleTestPlugin().register()
    log_message("Plugin registered successfully")
    
except Exception as e:
    log_message(f"ERROR in ultra_simple_test.py: {e}")
    import traceback
    log_message(f"Traceback: {traceback.format_exc()}")
