#!/usr/bin/env python3
"""
OrthoRoute IPC Plugin - FIXED Track Creation
Complete rebuild focusing on actually creating tracks that appear on the board
"""

import os
import sys
import json
import tempfile
import time
import subprocess
from pathlib import Path

# Import KiCad IPC API
try:
    from kipy import KiCad
    from kipy.board import Board
    from kipy.board_types import Track, Net, Via
    from kipy.util.units import to_mm, from_mm
    from kipy.geometry import Vector2
    print("✅ KiCad IPC API (kipy) imported successfully")
    KIPY_AVAILABLE = True
except ImportError as e:
    print(f"❌ Failed to import KiCad IPC API: {e}")
    print("Please install: pip install kicad-python")
    # Don't call sys.exit(1) - this kills KiCad entirely!
    KIPY_AVAILABLE = False

def main():
    """Main entry point for OrthoRoute IPC Plugin"""
    print("🚀 OrthoRoute IPC Plugin Starting...")
    
    try:
        # Connect to KiCad
        kicad = KiCad()
        print("✅ Connected to KiCad IPC API")
        
        # Get the active board
        board = kicad.get_board()
        if not board:
            print("❌ No active board found!")
            return
        
        print("✅ Got active board")
        
        # Simple test: Create a single test track first
        test_track_creation(board)
        
        # Extract board data and run full routing
        run_full_routing(board)
        
    except Exception as e:
        print(f"❌ Error in OrthoRoute IPC Plugin: {e}")
        import traceback
        traceback.print_exc()

def test_track_creation(board):
    """Test creating a simple track to verify the API works"""
    print("🧪 Testing basic track creation...")
    
    try:
        # Create a simple test track
        test_track = Track()
        
        # Set basic properties
        test_track.start = Vector2(10000000, 10000000)  # 10mm, 10mm
        test_track.end = Vector2(20000000, 10000000)    # 20mm, 10mm  
        test_track.width = 200000  # 0.2mm
        test_track.layer = 0  # F.Cu
        
        # Try to get any net for the track
        nets = board.get_nets()
        if nets:
            # Use the first available net
            test_track.net = nets[0]
            print(f"✅ Using net: {nets[0].name}")
        
        print("✅ Test track object created")
        
        # Try to add it to the board
        board.create_items([test_track])
        print("✅ Test track added to board")
        
        # Save the board
        board.save()
        print("✅ Board saved - TEST TRACK SHOULD BE VISIBLE!")
        
    except Exception as e:
        print(f"❌ Test track creation failed: {e}")
        import traceback
        traceback.print_exc()

def run_full_routing(board):
    """Run the full routing process"""
    print("📊 Starting full routing process...")
    
    try:
        # Extract board data
        board_data = extract_board_data(board)
        
        # Launch routing server
        routing_results = launch_routing_server(board_data)
        
        if routing_results and routing_results.get('success'):
            # Apply results with improved track creation
            tracks_created = apply_routing_results_fixed(board, routing_results)
            
            if tracks_created > 0:
                # Force save
                board.save()
                print(f"🎉 SUCCESS: Created {tracks_created} tracks and saved board!")
            else:
                print("⚠️ No tracks were created")
        else:
            print("❌ Routing failed or no results")
            
    except Exception as e:
        print(f"❌ Full routing failed: {e}")
        import traceback
        traceback.print_exc()

def extract_board_data(board):
    """Extract board data for routing"""
    print("📊 Extracting board data...")
    
    try:
        # Get nets and footprints
        nets = board.get_nets()
        footprints = board.get_footprints()
        
        print(f"Found {len(nets)} nets, {len(footprints)} footprints")
        
        # Calculate board bounds
        if footprints:
            min_x = min_y = float('inf')
            max_x = max_y = float('-inf')
            
            for fp in footprints:
                pos = fp.position
                min_x = min(min_x, pos.x)
                max_x = max(max_x, pos.x)
                min_y = min(min_y, pos.y)
                max_y = max(max_y, pos.y)
            
            width_nm = int(max_x - min_x) + 20000000  # 20mm margin
            height_nm = int(max_y - min_y) + 20000000
        else:
            width_nm = height_nm = 50000000  # 50mm default
        
        board_data = {
            "bounds": {
                "width_nm": width_nm,
                "height_nm": height_nm,
                "layers": 2
            },
            "nets": []
        }
        
        # Extract routeable nets
        for net in nets:
            if not net.name or net.name.strip() == "" or net.name.strip() == "unconnected":
                continue
            
            # Get pads for this net
            net_pads = []
            
            for footprint in footprints:
                try:
                    pads = footprint.definition.pads
                    for pad in pads:
                        if pad.net and pad.net.name == net.name:
                            # Calculate absolute pad position
                            abs_x = int(footprint.position.x + pad.position.x)
                            abs_y = int(footprint.position.y + pad.position.y)
                            
                            net_pads.append({
                                'x': abs_x,
                                'y': abs_y,
                                'layer': 0,
                                'pad_name': f"{footprint.reference_field.text.value}.{pad.number}"
                            })
                except Exception as e:
                    print(f"Warning: pad extraction error: {e}")
                    continue
            
            # Only add nets with multiple pads
            if len(net_pads) >= 2:
                board_data["nets"].append({
                    'id': hash(net.name) & 0x7FFFFFFF,
                    'name': net.name,
                    'pins': net_pads,
                    'width_nm': 200000,
                    'net_object': net  # Store the actual net object
                })
                
                print(f"✅ Net '{net.name}' has {len(net_pads)} pads")
        
        print(f"✅ Extracted {len(board_data['nets'])} routeable nets")
        return board_data
        
    except Exception as e:
        print(f"❌ Board data extraction failed: {e}")
        import traceback
        traceback.print_exc()
        return None

def launch_routing_server(board_data):
    """Launch GPU routing server and get results"""
    print("🚀 Launching GPU routing server...")
    
    try:
        # Create work directory
        work_dir = Path(tempfile.mkdtemp(prefix="orthoroute_"))
        print(f"Work dir: {work_dir}")
        
        # Write routing request
        request_file = work_dir / "routing_request.json"
        server_request = {
            'board_data': board_data,
            'config': {
                'grid_size': 100,
                'max_iterations': 5,
                'via_cost': 10
            }
        }
        
        # Remove net_object before JSON serialization
        clean_board_data = json.loads(json.dumps(server_request, default=str))
        
        with open(request_file, 'w') as f:
            json.dump(clean_board_data, f, indent=2)
        
        # Launch server
        script_dir = Path(__file__).parent
        server_script = script_dir / "orthoroute_standalone_server.py"
        
        print(f"Launching server: {server_script}")
        
        # Run server process
        process = subprocess.Popen([
            sys.executable, str(server_script),
            "--work-dir", str(work_dir)
        ], capture_output=True, text=True)
        
        # Wait for server to complete
        stdout, stderr = process.communicate(timeout=30)
        
        print(f"Server stdout: {stdout}")
        if stderr:
            print(f"Server stderr: {stderr}")
        
        # Read results
        result_file = work_dir / "routing_result.json"
        if result_file.exists():
            with open(result_file, 'r') as f:
                results = json.load(f)
            
            # Re-attach net objects to results
            for net_result in results.get('routed_nets', []):
                net_name = net_result.get('net_name')
                for net_data in board_data['nets']:
                    if net_data['name'] == net_name:
                        net_result['net_object'] = net_data['net_object']
                        break
            
            return results
        else:
            print("❌ No results file found")
            return None
            
    except Exception as e:
        print(f"❌ Server launch failed: {e}")
        import traceback
        traceback.print_exc()
        return None

def apply_routing_results_fixed(board, routing_results):
    """Apply routing results with FIXED track creation"""
    print("📝 Applying routing results (FIXED VERSION)...")
    
    tracks_created = 0
    
    try:
        # Get routed nets
        routed_nets = routing_results.get('routed_nets', [])
        print(f"Processing {len(routed_nets)} routed nets")
        
        # Create all tracks at once
        all_tracks = []
        
        for net_result in routed_nets:
            if not net_result.get('success', False):
                continue
            
            net_name = net_result.get('net_name')
            net_object = net_result.get('net_object')
            path_points = net_result.get('path', [])
            
            if not net_object or len(path_points) < 2:
                print(f"⚠️ Skipping {net_name}: missing net object or insufficient points")
                continue
            
            print(f"🔗 Creating tracks for {net_name} with {len(path_points)} points")
            
            # Create track segments
            for i in range(len(path_points) - 1):
                start_point = path_points[i]
                end_point = path_points[i + 1]
                
                try:
                    # Create track with explicit properties
                    track = Track()
                    track.start = Vector2(int(start_point['x']), int(start_point['y']))
                    track.end = Vector2(int(end_point['x']), int(end_point['y']))
                    track.width = 200000  # 0.2mm in nanometers
                    track.layer = 0  # F.Cu layer
                    track.net = net_object
                    
                    all_tracks.append(track)
                    tracks_created += 1
                    
                    print(f"  ✅ Track {i+1}: ({start_point['x']:.0f}, {start_point['y']:.0f}) → ({end_point['x']:.0f}, {end_point['y']:.0f})")
                    
                except Exception as e:
                    print(f"  ❌ Failed to create track segment: {e}")
                    continue
        
        # Add all tracks to board in one operation
        if all_tracks:
            print(f"🎯 Adding {len(all_tracks)} tracks to board...")
            
            # Use transaction for atomic operation
            commit = board.begin_commit()
            try:
                created_items = board.create_items(all_tracks)
                board.push_commit(commit, "OrthoRoute GPU autorouting")
                
                print(f"✅ Successfully added {len(created_items)} tracks to board")
                print("💾 Saving board...")
                
                # Force save
                board.save()
                
                print("🎉 TRACKS CREATED AND SAVED! Check your board!")
                
            except Exception as e:
                print(f"❌ Failed to commit tracks: {e}")
                import traceback
                traceback.print_exc()
        else:
            print("❌ No tracks to add")
        
    except Exception as e:
        print(f"❌ Track application failed: {e}")
        import traceback
        traceback.print_exc()
    
    return tracks_created

if __name__ == "__main__":
    main()
