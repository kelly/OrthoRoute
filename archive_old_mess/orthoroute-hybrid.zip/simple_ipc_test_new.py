#!/usr/bin/env python3
"""
Simple IPC Test Plugin - KiCad 9.0+ IPC API Test
Tests basic KiCad IPC API connection and creates one test track
"""

import os
import sys
import time
import traceback

def log_message(message):
    """Log messages with timestamp"""
    timestamp = time.strftime("%H:%M:%S")
    print(f"[{timestamp}] {message}")

# Import KiCad IPC API
try:
    from kipy import KiCad
    from kipy.board_types import Track
    from kipy.util.units import to_mm, from_mm
    from kipy.geometry import Vector2
    IPC_AVAILABLE = True
    log_message("✅ KiCad IPC API (kipy) imported successfully")
except ImportError as e:
    log_message(f"❌ Failed to import KiCad IPC API: {e}")
    log_message("Please install: pip install kicad-python")
    IPC_AVAILABLE = False

class SimpleIPCTestPlugin:
    """Simple IPC Test Plugin Class - KiCad 9.0+ Style"""
    
    def __init__(self):
        """Initialize the plugin"""
        self.kicad = None
        self.board = None

    def run(self):
        """Main plugin execution method - IPC Plugin Pattern"""
        log_message("🧪 Simple IPC Test Plugin Starting...")
        
        if not IPC_AVAILABLE:
            log_message("❌ KiCad IPC API not available")
            return 1
            
        try:
            # Connect to KiCad
            log_message("🔌 Connecting to KiCad...")
            self.kicad = KiCad()
            
            # Get the active board
            log_message("📋 Getting active board...")
            self.board = self.kicad.get_board()
            if not self.board:
                log_message("❌ No active board found")
                return 1
                
            # Get board info
            bbox = self.board.get_bounding_box()
            width_mm = to_mm(bbox.width)
            height_mm = to_mm(bbox.height)
            
            log_message(f"📏 Board: {width_mm:.1f} × {height_mm:.1f} mm")
            
            # Create a simple test track
            log_message("✏️  Creating test track...")
            
            track = Track()
            track.start = Vector2(from_mm(10), from_mm(10))  # 10mm, 10mm
            track.end = Vector2(from_mm(30), from_mm(10))    # 30mm, 10mm
            track.width = from_mm(0.2)                       # 0.2mm width
            track.layer = 0                                  # Top layer
            
            # Add track to board
            self.board.add_track(track)
            
            # Refresh board
            self.board.refresh()
            
            log_message("✅ Test track created successfully!")
            log_message("🎯 Simple IPC Test completed successfully!")
            
            return 0
            
        except Exception as e:
            log_message(f"❌ Error in Simple IPC Test: {e}")
            traceback.print_exc()
            return 1

# IPC Plugin Pattern - Direct instantiation and execution
if __name__ == "__main__":
    try:
        plugin = SimpleIPCTestPlugin()
        exit_code = plugin.run()
        log_message(f"🏁 Test finished with exit code: {exit_code}")
        # Don't call sys.exit() in plugin context - this kills KiCad
        # sys.exit(exit_code)
    except Exception as e:
        log_message(f"❌ Fatal error: {e}")
        traceback.print_exc()
        # Don't call sys.exit(1) - this kills KiCad
        # sys.exit(1)
