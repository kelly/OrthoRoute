#!/usr/bin/env python3
"""
OrthoRoute IPC Plugin Entry Point
Proper KiCad 9.0+ IPC API plugin implementation
"""

import os
import sys
import json
import tempfile
import time
import subprocess
from pathlib import Path

# Import KiCad IPC API
try:
    from kipy import KiCad
    from kipy.board import Board
    from kipy.board_types import Track, Net
    from kipy.util.units import to_mm, from_mm
    from kipy.geometry import Vector2
    print("✅ KiCad IPC API (kipy) imported successfully")
    KIPY_AVAILABLE = True
except ImportError as e:
    print(f"❌ Failed to import KiCad IPC API: {e}")
    print("Please install: pip install kicad-python")
    # Don't call sys.exit(1) - this kills KiCad entirely!
    # Instead, we'll handle this gracefully in the plugin execution
    KIPY_AVAILABLE = False

def find_kicad_api_socket():
    """Try to find KiCad's API socket manually"""
    print("🔍 Searching for KiCad API socket...")
    
    # First try the specific path mentioned by the user
    user_socket = Path(r"C:\Users\Benchoff\AppData\Local\Temp\kicad\api.sock")
    if user_socket.exists():
        print(f"✅ Found socket at user-specified path: {user_socket}")
        return str(user_socket), ""
    
    # Common socket locations
    temp_dir = Path(tempfile.gettempdir())
    possible_paths = [
        temp_dir / "kicad" / "api.sock",
        temp_dir / "api.sock",
    ]
    
    # Look for socket files with PID suffix
    kicad_temp = temp_dir / "kicad"
    if kicad_temp.exists():
        for file in kicad_temp.glob("api*.sock"):
            possible_paths.append(file)
    
    # Try to find any socket file in temp
    for file in temp_dir.glob("**/api*.sock"):
        possible_paths.append(file)
    
    for socket_path in possible_paths:
        if socket_path.exists():
            print(f"✅ Found socket at: {socket_path}")
            # For manual connection, we don't have a token, so try empty string
            return str(socket_path), ""
    
    print("❌ No KiCad API socket found")
    return None, None

def main():
    """Main entry point for the IPC plugin"""
    print("🚀 OrthoRoute IPC Plugin Starting...")
    
    # Get connection info from environment variables set by KiCad
    api_socket = os.environ.get('KICAD_API_SOCKET')
    api_token = os.environ.get('KICAD_API_TOKEN')
    
    print(f"API Socket: {api_socket}")
    print(f"API Token: {'***' if api_token else 'None'}")
    
    # If environment variables aren't set, try to find the socket manually
    if not api_socket or not api_token:
        print("⚠️  Environment variables not set, attempting manual connection...")
        api_socket, api_token = find_kicad_api_socket()
    
    if not api_socket:
        print("❌ Could not find KiCad API connection info")
        print("Make sure KiCad's IPC API is enabled in preferences")
        return
    
    try:
        # Connect to KiCad via IPC API
        print("🔌 Connecting to KiCad...")
        
        # Handle the ipc:// prefix if present
        socket_path = api_socket
        if socket_path.startswith('ipc://'):
            socket_path = socket_path[6:]  # Remove ipc:// prefix
        
        print(f"Using socket path: {socket_path}")
        kicad = KiCad(socket_path=socket_path, token=api_token)
        
        # Get the active board
        print("📋 Getting active board...")
        board = kicad.get_board()
        if not board:
            print("❌ No active board found")
            return
            
        # Get board info
        # Note: for KiCad IPC API we need to get the bounding box differently
        try:
            # Try to get board bounding box - this might not be directly available
            # For now, let's get footprints and calculate bounds from them
            footprints = board.get_footprints()
            
            if footprints:
                min_x = min_y = float('inf')
                max_x = max_y = float('-inf')
                
                for fp in footprints:
                    pos = fp.position
                    min_x = min(min_x, pos.x)
                    max_x = max(max_x, pos.x)
                    min_y = min(min_y, pos.y)
                    max_y = max(max_y, pos.y)
                
                width_mm = to_mm(max_x - min_x) + 20  # Add some margin
                height_mm = to_mm(max_y - min_y) + 20
            else:
                # Default size if no footprints
                width_mm = 50.0
                height_mm = 50.0
        except Exception as e:
            print(f"⚠️  Could not calculate board bounds: {e}")
            width_mm = 50.0
            height_mm = 50.0
        
        # Count nets
        nets = board.get_nets()
        net_count = len([net for net in nets if net.name and net.name.strip()])
        
        print(f"📏 Board: {width_mm:.1f} × {height_mm:.1f} mm")
        print(f"🔗 Nets: {net_count}")
        
        # Create routing request
        routing_request = {
            "board_info": {
                "width_mm": width_mm,
                "height_mm": height_mm,
                "net_count": net_count
            },
            "nets": []
        }
        
        # Add net information
        for net in nets:
            if net.name and net.name.strip():
                net_info = {
                    "name": net.name,
                    "id": net.net_id if hasattr(net, 'net_id') else 0,
                    "pads": []
                }
                routing_request["nets"].append(net_info)
        
        print(f"✅ Prepared routing request for {len(routing_request['nets'])} nets")
        
        # Extract complete board data for routing
        board_data = extract_full_board_data(board)
        
        # Launch GPU routing server and get results
        routing_results = launch_routing_server(board_data)
        
        if routing_results and routing_results.get('success'):
            # Apply routing results back to the board
            tracks_created = apply_routing_results(board, routing_results)
            
            # Save changes
            board.save()
            print(f"✅ Successfully routed {tracks_created} tracks!")
            print("🎯 OrthoRoute IPC Plugin completed successfully!")
        else:
            print("⚠️  Routing failed or no results returned")
        
    except Exception as e:
        print(f"❌ Error in OrthoRoute IPC Plugin: {e}")
        import traceback
        traceback.print_exc()

def extract_full_board_data(board):
    """Extract complete board data including nets, pads, and obstacles"""
    print("📊 Extracting complete board data...")
    
    # Get board dimensions (rough estimate from footprints)
    try:
        footprints = board.get_footprints()
        
        if footprints:
            min_x = min_y = float('inf')
            max_x = max_y = float('-inf')
            
            for fp in footprints:
                pos = fp.position
                min_x = min(min_x, pos.x)
                max_x = max(max_x, pos.x)
                min_y = min(min_y, pos.y)
                max_y = max(max_y, pos.y)
            
            width_nm = int(max_x - min_x) + 20000000  # 20mm margin
            height_nm = int(max_y - min_y) + 20000000
        else:
            width_nm = 50000000  # 50mm default
            height_nm = 50000000
    except Exception as e:
        print(f"⚠️  Error calculating board size: {e}")
        width_nm = 50000000
        height_nm = 50000000
    
    board_data = {
        "bounds": {
            "width_nm": width_nm,
            "height_nm": height_nm,
            "layers": 2  # Default to 2 layers
        },
        "nets": []
    }
    
    # Extract nets with pads
    try:
        nets = board.get_nets()
        footprints = board.get_footprints()
        
        for net in nets:
            if not net.name or net.name.strip() == "" or net.name.strip() == "unconnected":
                continue
                
            # Get pads for this net
            net_pads = []
            
            for footprint in footprints:
                try:
                    # Get pads from footprint definition
                    pads = footprint.definition.pads
                    for pad in pads:
                        if pad.net and pad.net.name == net.name:
                            # Convert pad position (relative to footprint) to absolute position
                            abs_x = int(footprint.position.x + pad.position.x)
                            abs_y = int(footprint.position.y + pad.position.y)
                            
                            net_pads.append({
                                'x': abs_x,
                                'y': abs_y,
                                'layer': 0,  # Default to top layer
                                'pad_name': f"{footprint.reference_field.text.value}.{pad.number}"
                            })
                except Exception as e:
                    print(f"Warning: Could not extract pads from footprint: {e}")
                    continue
            
            # Only add nets with at least 2 pads (routeable)
            if len(net_pads) >= 2:
                board_data["nets"].append({
                    'id': hash(net.name) & 0x7FFFFFFF,  # Simple ID from hash
                    'name': net.name,
                    'pins': net_pads,
                    'width_nm': 200000,  # Default 0.2mm trace width
                    'kicad_net': net
                })
                
                print(f"✅ Net '{net.name}' has {len(net_pads)} pads")
    
    except Exception as e:
        print(f"❌ Error extracting nets: {e}")
        import traceback
        traceback.print_exc()
    
    print(f"✅ Extracted {len(board_data['nets'])} routeable nets")
    return board_data

def launch_routing_server(board_data):
    """Launch the standalone routing server and wait for results"""
    print("🚀 Launching GPU routing server...")
    
    try:
        # Create temporary work directory
        work_dir = Path(tempfile.mkdtemp(prefix="orthoroute_"))
        print(f"Working directory: {work_dir}")
        
        # Write routing request
        request_file = work_dir / "routing_request.json"
        
        # Format request for server (server expects 'board_data' key)
        server_request = {
            'board_data': board_data,
            'config': {
                'grid_size': 100,
                'max_iterations': 5,
                'via_cost': 10
            }
        }
        
        with open(request_file, 'w') as f:
            json.dump(server_request, f, indent=2, default=str)
        
        # Path to standalone server
        script_dir = Path(__file__).parent
        server_script = script_dir / "orthoroute_standalone_server.py"
        
        if not server_script.exists():
            print(f"❌ Server script not found: {server_script}")
            return None
        
        # Launch server process
        cmd = [sys.executable, str(server_script), "--work-dir", str(work_dir)]
        print(f"Launching: {' '.join(cmd)}")
        
        process = subprocess.Popen(cmd, 
                                 stdout=subprocess.PIPE, 
                                 stderr=subprocess.PIPE,
                                 text=True)
        
        # Wait for completion with timeout
        timeout = 300  # 5 minutes
        try:
            stdout, stderr = process.communicate(timeout=timeout)
            print(f"Server output: {stdout}")
            if stderr:
                print(f"Server errors: {stderr}")
        except subprocess.TimeoutExpired:
            print("❌ Routing server timeout")
            process.kill()
            return None
        
        # Check for result file
        result_file = work_dir / "routing_result.json"
        if result_file.exists():
            with open(result_file, 'r') as f:
                return json.load(f)
        else:
            print("❌ No routing results file found")
            return None
            
    except Exception as e:
        print(f"❌ Error launching routing server: {e}")
        return None

def apply_routing_results(board, routing_results):
    """Apply routing results to the KiCad board using IPC API"""
    print("📝 Applying routing results to board...")
    
    tracks_created = 0
    
    try:
        # Begin a commit transaction to group all changes
        commit = board.begin_commit()
        
        # Process routed nets from server results
        routed_nets = routing_results.get('routed_nets', [])
        
        # Get all nets for lookup
        board_nets = {net.name: net for net in board.get_nets()}
        
        for net_result in routed_nets:
            net_name = net_result.get('net_name')
            if not net_result.get('success', False):
                print(f"⚠️  Net {net_name} not successfully routed")
                continue
            
            # Find the net object
            net = board_nets.get(net_name)
            if not net:
                print(f"❌ Net {net_name} not found in board")
                continue
            
            # Get the path points
            path_points = net_result.get('path', [])
            if len(path_points) < 2:
                print(f"⚠️  Net {net_name} has insufficient path points")
                continue
            
            print(f"🔗 Creating {len(path_points)-1} track segments for net {net_name}")
            
            # Create track segments between consecutive points
            tracks_to_create = []
            
            for i in range(len(path_points) - 1):
                start_point = path_points[i]
                end_point = path_points[i + 1]
                
                try:
                    # Create Track object using the correct API
                    track = Track()
                    track.start = Vector2(start_point['x'], start_point['y'])
                    track.end = Vector2(end_point['x'], end_point['y'])
                    track.width = 200000  # 0.2mm in nanometers
                    track.layer = 0  # F.Cu layer
                    track.net = net
                    
                    tracks_to_create.append(track)
                    tracks_created += 1
                    
                except Exception as e:
                    print(f"❌ Error creating track segment for {net_name}: {e}")
                    continue
            
            # Add all tracks for this net to the board
            if tracks_to_create:
                try:
                    created_tracks = board.create_items(tracks_to_create)
                    print(f"✅ Successfully added {len(created_tracks)} tracks for net {net_name}")
                except Exception as e:
                    print(f"❌ Error adding tracks to board for {net_name}: {e}")
        
        # Push the commit to apply all changes
        board.push_commit(commit, "OrthoRoute GPU autorouting")
        print(f"✅ Successfully created {tracks_created} track segments")
        
    except Exception as e:
        print(f"❌ Error applying routing results: {e}")
        import traceback
        traceback.print_exc()
    
    return tracks_created

if __name__ == "__main__":
    main()