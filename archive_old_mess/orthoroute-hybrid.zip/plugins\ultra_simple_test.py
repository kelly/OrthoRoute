#!/usr/bin/env python3
"""
Ultra Simple Test - Hybrid ActionPlugin + IPC for KiCad 9.0+
Uses ActionPlugin for toolbar integration, IPC API for execution
"""

import time
import os
import sys

# Log to a file so we can see if KiCad is even trying to load this
log_file = os.path.join(os.path.expanduser("~"), "kicad_plugin_test.log")

def log_message(message):
    """Helper function to log messages"""
    try:
        with open(log_file, "a") as f:
            timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
            f.write(f"[{timestamp}] {message}\n")
            f.flush()
    except Exception as e:
        print(f"Logging error: {e}")

try:
    import pcbnew
    log_message("pcbnew imported successfully")
    
    class UltraSimpleTestPlugin(pcbnew.ActionPlugin):
        def defaults(self):
            """Required method to define plugin properties"""
            self.name = "Ultra Simple Test"
            self.category = "Testing"
            self.description = "Ultra simple test to verify plugin loading with IPC API"
            self.show_toolbar_button = True
            self.icon_file_name = "icon.png"
            log_message("Plugin defaults() called")
        
        def Run(self):
            """Method called when plugin is executed - uses IPC API"""
            log_message("Plugin Run() method executed!")
            
            try:
                # Import KiCad IPC API
                from kipy import KiCad
                log_message("✅ KiCad IPC API (kipy) imported successfully")
                
                # Connect to KiCad
                kicad = KiCad()
                log_message("✅ Connected to KiCad via IPC")
                
                # Show success message
                import wx
                wx.MessageBox(f"Ultra Simple Test Plugin executed successfully via IPC!\n\nCheck log: {log_file}", 
                             "Success", wx.OK | wx.ICON_INFORMATION)
                
                log_message("✅ Plugin execution completed successfully")
                
            except Exception as e:
                error_msg = f"ERROR in IPC execution: {e}"
                log_message(error_msg)
                import wx
                wx.MessageBox(f"IPC execution failed:\n{error_msg}\n\nFalling back to SWIG mode", 
                             "Warning", wx.OK | wx.ICON_WARNING)
                
                # Fallback to SWIG mode
                log_message("Falling back to SWIG mode")
                import wx
                wx.MessageBox("Plugin executed in SWIG fallback mode!", 
                             "Fallback Success", wx.OK | wx.ICON_INFORMATION)
    
    # Register the plugin
    UltraSimpleTestPlugin().register()
    log_message("Plugin registered successfully")
    
except Exception as e:
    log_message(f"ERROR in ultra_simple_test.py: {e}")
    import traceback
    log_message(f"Traceback: {traceback.format_exc()}")
