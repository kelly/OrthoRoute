#!/usr/bin/env python3
"""
Ultra Simple Test - IPC Plugin for KiCad 9.0+
"""

import time
import os
import sys

# Log to a file so we can see if KiCad is even trying to load this
log_file = os.path.join(os.path.expanduser("~"), "kicad_plugin_test.log")

def log_message(message):
    """Helper function to log messages"""
    try:
        with open(log_file, "a") as f:
            timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
            f.write(f"[{timestamp}] {message}\n")
            f.flush()
    except Exception as e:
        print(f"Logging error: {e}")

def main():
    """Main entry point for IPC plugin"""
    log_message("Ultra Simple Test IPC plugin started")
    
    try:
        # Import KiCad IPC API
        from kipy import KiCad
        log_message("✅ KiCad IPC API (kipy) imported successfully")
        
        # Connect to KiCad
        kicad = KiCad()
        log_message("✅ Connected to KiCad via IPC")
        
        # Show success message
        print("Ultra Simple Test Plugin executed successfully via IPC!")
        print("Check the log file at:", log_file)
        
        log_message("✅ Plugin execution completed successfully")
        
        return 0
        
    except Exception as e:
        error_msg = f"ERROR in ultra_simple_test.py: {e}"
        log_message(error_msg)
        print(error_msg)
        import traceback
        log_message(f"Traceback: {traceback.format_exc()}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
