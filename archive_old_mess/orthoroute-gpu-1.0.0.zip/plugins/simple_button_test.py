#!/usr/bin/env python3
"""
Super Simple Button Test - Just proves the button works
Based on KiCad 9.0 IPC plugin forum discussion
"""

import time
import os
import sys
import traceback

def main():
    """Main entry point - called by KiCad when button is clicked"""
    
    # Write to user's Documents folder
    log_file = os.path.join(os.path.expanduser("~"), "Documents", "kicad_button_test.txt")
    
    try:
        # Create a timestamp
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        
        # Write basic info first
        with open(log_file, "w") as f:
            f.write(f"SUCCESS! KiCad IPC Plugin Button Clicked!\n")
            f.write(f"Timestamp: {timestamp}\n")
            f.flush()  # Force write to disk
            
            # Add more detailed info
            f.write(f"Python executable: {sys.executable}\n") 
            f.write(f"Working directory: {os.getcwd()}\n")
            f.write(f"Command line args: {' '.join(sys.argv)}\n")
            f.write(f"Python version: {sys.version}\n")
            f.flush()  # Force write to disk
            
            # Environment variables
            f.write(f"Environment variables with 'KICAD':\n")
            kicad_vars_found = 0
            for key, value in os.environ.items():
                if 'KICAD' in key.upper():
                    f.write(f"  {key} = {value}\n")
                    kicad_vars_found += 1
            
            if kicad_vars_found == 0:
                f.write("  (No KICAD environment variables found)\n")
            
            f.write(f"\nAll environment variables ({len(os.environ)}):\n")
            for key, value in sorted(os.environ.items()):
                f.write(f"  {key} = {value}\n")
            
            f.flush()  # Final flush
        
        print(f"Button test successful! Check: {log_file}")
        return 0
        
    except Exception as e:
        # Fallback error logging
        try:
            with open(log_file, "w") as f:
                f.write(f"ERROR in simple_button_test.py: {e}\n")
                f.write(f"Traceback: {traceback.format_exc()}\n")
                f.write(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        except:
            pass  # If we can't even write the error, give up
        
        print(f"Error: {e}")
        return 1

if __name__ == "__main__":
    main()
