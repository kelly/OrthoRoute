#!/usr/bin/env python3
"""
Simple Track Test Plugin
Just draws ONE track to test KiCad IPC API
NO GPU, NO ROUTING, NO COMPLEXITY - just basic track creation
"""

import sys

def main():
    """Draw one simple track and that's it"""
    print("🧪 SIMPLE TRACK TEST - Starting...")
    
    try:
        # Import KiCad IPC API
        print("📥 Importing KiCad API...")
        from kipy import KiCad
        from kipy.board import Board
        from kipy.board_types import Track
        from kipy.geometry import Vector2
        print("✅ KiCad API imported successfully")
        
        # Connect to KiCad
        print("🔌 Connecting to KiCad...")
        kicad = KiCad()
        board = kicad.get_board()
        
        if not board:
            print("❌ No board found!")
            return
        print("✅ Connected to board")
        
        # Get basic board info
        print("📊 Reading board info...")
        nets = board.get_nets()
        footprints = board.get_footprints()
        print(f"   📋 Found {len(nets)} nets")
        print(f"   📦 Found {len(footprints)} footprints")
        
        # Create ONE simple track
        print("🔨 Creating one test track...")
        
        # Create track object
        test_track = Track()
        
        # Set track properties (10mm to 30mm horizontally at 10mm vertical)
        test_track.start = Vector2(10000000, 10000000)  # 10mm, 10mm
        test_track.end = Vector2(30000000, 10000000)    # 30mm, 10mm
        test_track.width = 250000  # 0.25mm wide
        test_track.layer = 0  # F.Cu (front copper)
        
        print(f"   📍 Track: (10mm, 10mm) → (30mm, 10mm)")
        print(f"   📏 Width: 0.25mm")
        print(f"   🔧 Layer: F.Cu")
        
        # Try to assign to first available net (optional)
        if nets and len(nets) > 0:
            test_track.net = nets[0]
            print(f"   🌐 Assigned to net: {nets[0].name}")
        
        print("✅ Track object created")
        
        # Add track to board
        print("📌 Adding track to board...")
        result = board.create_items([test_track])
        print(f"✅ create_items returned: {result}")
        
        # Save board
        print("💾 Saving board...")
        board.save()
        print("✅ Board saved")
        
        print("\n🎉 SUCCESS! Check your board for a test track!")
        print("   📍 Look for a horizontal track at (10mm, 10mm) → (30mm, 10mm)")
        print("   📏 0.25mm wide on the front copper layer")
        
    except ImportError as e:
        print(f"❌ KiCad API import failed: {e}")
        print("💡 Install with: pip install kicad-python")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        
    finally:
        print("🏁 Simple track test completed")

if __name__ == "__main__":
    main()
