#!/usr/bin/env python3
"""
Simple launcher script for OrthoRoute GPU server
No command line arguments - uses environment variables and config files
Designed for maximum compatibility with KiCad's embedded Python
"""

import sys
import os
import json
import time
import tempfile
from pathlib import Path

def main():
    """Launch GPU server using environment variables instead of arguments"""
    
    # Get work directory from environment variable or create temp dir
    work_dir = os.environ.get('ORTHOROUTE_WORK_DIR')
    if not work_dir:
        work_dir = tempfile.mkdtemp(prefix='orthoroute_')
    
    work_dir = Path(work_dir)
    work_dir.mkdir(exist_ok=True)
    
    print(f"[LAUNCHER] Starting GPU server")
    print(f"[LAUNCHER] Work directory: {work_dir}")
    print(f"[LAUNCHER] Python: {sys.executable}")
    
    # Look for config file
    config_file = work_dir / "launcher_config.json"
    if config_file.exists():
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
            print(f"[LAUNCHER] Loaded config: {config}")
        except Exception as e:
            print(f"[LAUNCHER] Config error: {e}")
            config = {}
    else:
        config = {}
    
    # Change to work directory
    os.chdir(str(work_dir))
    
    # Import and run the server
    try:
        # Add plugin directory to path
        plugin_dir = Path(__file__).parent
        sys.path.insert(0, str(plugin_dir))
        
        # Import the robust server
        print(f"[LAUNCHER] Importing robust_server from {plugin_dir}")
        import robust_server
        
        # Run the server with work directory - keep running until shutdown
        print(f"[LAUNCHER] Starting robust server - will run until shutdown signal")
        server = robust_server.OrthoRouteStandaloneServer(str(work_dir))
        
        # Run server in continuous mode (no timeout)
        print(f"[LAUNCHER] Server ready - monitoring for requests and shutdown signal")
        server.update_status("idle", 0, "Server ready - waiting for requests")
        
        # Main server loop - keep running until shutdown signal
        while True:
            # Check for shutdown signal
            if server.shutdown_file.exists():
                print(f"[LAUNCHER] Shutdown signal received - stopping server")
                break
            
            # Check for routing requests
            if server.input_file.exists():
                print(f"[LAUNCHER] Request received - processing...")
                try:
                    # Process the request
                    server.process_routing_request()
                    print(f"[LAUNCHER] Request processed - back to idle")
                except Exception as e:
                    print(f"[LAUNCHER] Request processing error: {e}")
                    server.update_status("error", 0, f"Processing error: {e}")
            
            # Wait before checking again
            time.sleep(0.5)
        
        print(f"[LAUNCHER] Server stopped gracefully")
        
    except KeyboardInterrupt:
        print(f"[LAUNCHER] Keyboard interrupt - stopping server")
    except Exception as e:
        print(f"[LAUNCHER] Error: {e}")
        import traceback
        traceback.print_exc()
        
        # Write error to status file for plugin to see
        status_file = work_dir / "routing_status.json"
        try:
            status_data = {
                "status": "error",
                "progress": 0,
                "message": f"Launcher error: {e}",
                "timestamp": time.time()
            }
            with open(status_file, 'w') as f:
                json.dump(status_data, f, indent=2)
        except:
            pass

if __name__ == "__main__":
    main()
