#!/usr/bin/env python3
"""
Simple SWIG Plugin Test - Tests traditional KiCad plugin architecture
"""

import os
import sys
import traceback

def log_message(message):
    """Log messages with timestamp"""
    import time
    timestamp = time.strftime("%H:%M:%S")
    print(f"[{timestamp}] {message}")

# Test if we can import pcbnew
try:
    import pcbnew
    log_message("✅ pcbnew imported successfully")
    
    class SimpleSWIGTestPlugin(pcbnew.ActionPlugin):
        """Simple SWIG test plugin"""
        
        def defaults(self):
            self.name = "Simple SWIG Test"
            self.category = "Testing"
            self.description = "Test basic SWIG API functionality"
            self.show_toolbar_button = False
            
        def Run(self):
            log_message("🚀 Simple SWIG Test Plugin running...")
            
            try:
                board = pcbnew.GetBoard()
                if board:
                    log_message(f"✅ Board loaded: {board.GetFileName()}")
                    log_message("✅ SWIG Plugin test successful!")
                else:
                    log_message("❌ No board loaded")
                    
            except Exception as e:
                log_message(f"❌ Error in SWIG plugin: {e}")
                traceback.print_exc()
    
    # For PCM plugins, we don't register directly
    log_message("✅ SimpleSWIGTestPlugin class defined successfully")
    
except ImportError as e:
    log_message(f"❌ Failed to import pcbnew: {e}")
    sys.exit(1)

if __name__ == "__main__":
    log_message("🧪 SWIG Plugin Test Script")
    log_message("This should be called by KiCad, not run directly")
