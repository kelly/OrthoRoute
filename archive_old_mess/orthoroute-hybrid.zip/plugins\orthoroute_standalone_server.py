#!/usr/bin/env python3
"""
OrthoRoute Standalone GPU Server
Completely isolated GPU routing process that communicates via files
This runs OUTSIDE of KiCad's process space to avoid any crashes
"""

import json
import os
import sys
import time
import argparse
import traceback
from pathlib import Path
import subprocess

def log_message(message, log_file=None):
    """Thread-safe logging"""
    timestamp = time.strftime('%H:%M:%S')
    full_msg = f"[{timestamp}] {message}"
    print(full_msg)
    
    if log_file:
        try:
            with open(log_file, 'a', encoding='utf-8') as f:
                f.write(full_msg + "\n")
                f.flush()
        except Exception as e:
            print(f"Logging error: {e}")

class OrthoRouteStandaloneServer:
    """Standalone GPU routing server that runs outside KiCad"""
    
    def __init__(self, work_dir):
        self.work_dir = Path(work_dir)
        self.work_dir.mkdir(exist_ok=True)
        
        # Communication files
        self.input_file = self.work_dir / "routing_request.json"
        self.output_file = self.work_dir / "routing_result.json"
        self.status_file = self.work_dir / "routing_status.json"
        self.log_file = self.work_dir / "server.log"
        self.shutdown_file = self.work_dir / "shutdown.flag"
        
        # Clear any existing files
        for file in [self.input_file, self.output_file, self.status_file, self.shutdown_file]:
            if file.exists():
                file.unlink()
        
        log_message("[INIT] OrthoRoute Standalone Server initialized", self.log_file)
        log_message(f"[DIR] Work directory: {self.work_dir}", self.log_file)
    
    def update_status(self, status, progress=0, message=""):
        """Update status file for KiCad to read"""
        try:
            status_data = {
                "status": status,  # "idle", "working", "complete", "error"
                "progress": progress,
                "message": message,
                "timestamp": time.time()
            }
            
            with open(self.status_file, 'w') as f:
                json.dump(status_data, f, indent=2)
            
            log_message(f"[STATUS] Status: {status} ({progress}%) - {message}", self.log_file)
            
        except Exception as e:
            log_message(f"[WARN] Status update error: {e}", self.log_file)
    
    def load_gpu_modules(self):
        """Load GPU modules in isolated environment"""
        try:
            log_message("[LOAD] Loading GPU modules...", self.log_file)
            self.update_status("working", 5, "Loading GPU modules")
            
            # Import CuPy and other GPU modules here
            import cupy as cp
            import numpy as np
            
            # Test GPU functionality
            test_array = cp.array([1, 2, 3, 4, 5])
            test_result = cp.sum(test_array)
            
            log_message(f"[OK] GPU modules loaded successfully", self.log_file)
            log_message(f"[TEST] GPU test result: {test_result}", self.log_file)
            
            self.cp = cp
            self.np = np
            return True
            
        except Exception as e:
            log_message(f"[ERROR] GPU module loading failed: {e}", self.log_file)
            log_message(f"[TRACE] Stack trace:\n{traceback.format_exc()}", self.log_file)
            self.update_status("error", 0, f"GPU loading failed: {str(e)}")
            return False
    
    def process_routing_request(self, request_data):
        """Process routing request with GPU isolation"""
        try:
            log_message("🛣️ Starting routing process...", self.log_file)
            
            # Extract board data
            board_data = request_data.get('board_data', {})
            config = request_data.get('config', {})
            
            log_message(f"[INFO] Board nets: {len(board_data.get('nets', []))}", self.log_file)
            log_message(f"[INFO] Board tracks: {len(board_data.get('tracks', []))}", self.log_file)
            
            # Initialize routing engine in GPU
            self.update_status("working", 10, "Initializing GPU routing engine")
            
            # Simulate routing process with actual GPU operations
            total_nets = len(board_data.get('nets', []))
            routed_nets = []
            failed_nets = []
            
            for i, net in enumerate(board_data.get('nets', [])):
                progress = int(10 + (i / total_nets) * 80)
                self.update_status("working", progress, f"Routing net {i+1}/{total_nets}")
                
                try:
                    # Simulate GPU routing for this net
                    net_result = self.route_net_gpu(net, config)
                    
                    if net_result['success']:
                        routed_nets.append(net_result)
                        log_message(f"[OK] Net {net.get('name', i)} routed successfully", self.log_file)
                    else:
                        failed_nets.append({
                            'net': net,
                            'error': net_result.get('error', 'Unknown error')
                        })
                        log_message(f"[FAIL] Net {net.get('name', i)} routing failed", self.log_file)
                
                except Exception as e:
                    failed_nets.append({
                        'net': net,
                        'error': str(e)
                    })
                    log_message(f"[CRASH] Net {net.get('name', i)} crashed: {e}", self.log_file)
                
                # Small delay to prevent overwhelming
                time.sleep(0.01)
            
            # Calculate results
            success_rate = len(routed_nets) / total_nets * 100 if total_nets > 0 else 0
            
            result = {
                'success': True,
                'routed_nets': routed_nets,
                'failed_nets': failed_nets,
                'statistics': {
                    'total_nets': total_nets,
                    'routed_count': len(routed_nets),
                    'failed_count': len(failed_nets),
                    'success_rate': success_rate
                },
                'timestamp': time.time()
            }
            
            log_message(f"🎯 Routing completed: {success_rate:.1f}% success rate", self.log_file)
            self.update_status("complete", 100, f"Routing complete: {success_rate:.1f}% success")
            
            return result
            
        except Exception as e:
            log_message(f"[CRASH] Routing process crashed: {e}", self.log_file)
            log_message(f"[TRACE] Stack trace:\n{traceback.format_exc()}", self.log_file)
            
            error_result = {
                'success': False,
                'error': str(e),
                'traceback': traceback.format_exc(),
                'timestamp': time.time()
            }
            
            self.update_status("error", 0, f"Routing failed: {str(e)}")
            return error_result
    
    def route_net_gpu(self, net, config):
        """Route a single net using GPU"""
        try:
            # Simulate GPU-based routing
            # In real implementation, this would use CuPy/CUDA
            
            # Extract net information
            net_name = net.get('name', 'Unknown')
            pads = net.get('pads', [])
            
            if len(pads) < 2:
                return {
                    'success': False,
                    'error': 'Net has insufficient pads for routing'
                }
            
            # Simulate GPU grid-based routing
            start_pad = pads[0]
            end_pad = pads[-1]
            
            # Create GPU arrays for routing
            grid_size = config.get('grid_size', 100)
            routing_grid = self.cp.zeros((grid_size, grid_size), dtype=self.cp.int32)
            
            # Simulate wave expansion on GPU
            # This is a simplified version - real implementation would be more complex
            start_x = int(start_pad.get('x', 0) * grid_size / 1000)
            start_y = int(start_pad.get('y', 0) * grid_size / 1000)
            end_x = int(end_pad.get('x', 0) * grid_size / 1000)  
            end_y = int(end_pad.get('y', 0) * grid_size / 1000)
            
            # Simple path generation (in real version, this would be GPU wave routing)
            path_points = []
            
            # Direct line for simulation
            steps = max(abs(end_x - start_x), abs(end_y - start_y))
            if steps > 0:
                for i in range(steps + 1):
                    x = start_x + (end_x - start_x) * i // steps
                    y = start_y + (end_y - start_y) * i // steps
                    path_points.append({'x': x * 1000 // grid_size, 'y': y * 1000 // grid_size})
            
            # Force GPU synchronization
            self.cp.cuda.Device().synchronize()
            
            return {
                'success': True,
                'net_name': net_name,
                'path': path_points,
                'length': len(path_points),
                'gpu_time': 0.001  # Simulated timing
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'net_name': net.get('name', 'Unknown')
            }
    
    def run_server(self):
        """Main server loop"""
        try:
            log_message("[START] Starting OrthoRoute Standalone Server", self.log_file)
            
            # Load GPU modules
            if not self.load_gpu_modules():
                return False
            
            self.update_status("idle", 0, "Server ready - waiting for requests")
            
            # Main processing loop
            while True:
                try:
                    # Check for shutdown signal
                    if self.shutdown_file.exists():
                        log_message("[STOP] Shutdown signal received", self.log_file)
                        break
                    
                    # Check for new routing request
                    if self.input_file.exists():
                        log_message("📨 New routing request received", self.log_file)
                        
                        # Read request
                        with open(self.input_file, 'r') as f:
                            request_data = json.load(f)
                        
                        # Remove input file to prevent reprocessing
                        self.input_file.unlink()
                        
                        # Process request
                        result = self.process_routing_request(request_data)
                        
                        # Write result
                        with open(self.output_file, 'w') as f:
                            json.dump(result, f, indent=2)
                        
                        log_message("[OK] Request processed, result written", self.log_file)
                        
                        # Return to idle state
                        if result.get('success', False):
                            success_rate = result.get('statistics', {}).get('success_rate', 0)
                            self.update_status("idle", 0, f"Ready - Last job: {success_rate:.1f}% success")
                        else:
                            self.update_status("idle", 0, "Ready - Last job failed")
                    
                    # Small delay to prevent CPU spinning
                    time.sleep(0.1)
                
                except KeyboardInterrupt:
                    log_message("⌨️ Keyboard interrupt received", self.log_file)
                    break
                except Exception as e:
                    log_message(f"[WARN] Server loop error: {e}", self.log_file)
                    self.update_status("error", 0, f"Server error: {str(e)}")
                    time.sleep(1)  # Wait before retrying
            
            log_message("🏁 Server shutdown complete", self.log_file)
            return True
            
        except Exception as e:
            log_message(f"[CRASH] Server crashed: {e}", self.log_file)
            log_message(f"[TRACE] Stack trace:\n{traceback.format_exc()}", self.log_file)
            self.update_status("error", 0, f"Server crashed: {str(e)}")
            return False
        
        finally:
            # Cleanup
            try:
                # Clear GPU memory
                if hasattr(self, 'cp'):
                    self.cp.get_default_memory_pool().free_all_blocks()
                    log_message("[CLEAN] GPU memory cleared", self.log_file)
            except Exception as e:
                log_message(f"[WARN] GPU cleanup error: {e}", self.log_file)

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='OrthoRoute Standalone GPU Server')
    parser.add_argument('--work-dir', required=True, help='Working directory for communication files')
    parser.add_argument('--timeout', type=int, default=3600, help='Server timeout in seconds')
    
    args = parser.parse_args()
    
    print(f"[START] Starting OrthoRoute Standalone Server")
    print(f"[DIR] Work directory: {args.work_dir}")
    print(f"[TIMEOUT] Timeout: {args.timeout} seconds")
    print("[STOP] Press Ctrl+C to stop")
    
    server = OrthoRouteStandaloneServer(args.work_dir)
    
    try:
        success = server.run_server()
        return 0 if success else 1
    except KeyboardInterrupt:
        print("\n⌨️ Keyboard interrupt - shutting down...")
        return 0
    except Exception as e:
        print(f"[CRASH] Server failed: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
