"""
OrthoRoute GPU-Accelerated Autorouter
GPU-powered routing using CuPy and advanced algorithms
"""

import os
import sys
import json
import threading
import time
import subprocess
from pathlib import Path

# Add the package directory to Python path for imports
package_dir = Path(__file__).parent.parent
sys.path.insert(0, str(package_dir))

try:
    import cupy as cp
    import numpy as np
    GPU_AVAILABLE = True
    print("CuPy GPU acceleration available")
except ImportError:
    import numpy as np
    GPU_AVAILABLE = False
    print("CuPy not available, using CPU fallback")

try:
    from kicad_python import KiCadConnection
    KICAD_PYTHON_AVAILABLE = True
except ImportError:
    KICAD_PYTHON_AVAILABLE = False
    print("kicad-python not available, using subprocess IPC")

class GPURouter:
    """GPU-accelerated routing engine using CuPy"""
    
    def __init__(self):
        self.device = cp if GPU_AVAILABLE else np
        self.board_data = None
        self.routing_grid = None
        
    def create_routing_grid(self, board_bounds, resolution=0.1):
        """Create a routing grid for pathfinding"""
        width = int((board_bounds['max_x'] - board_bounds['min_x']) / resolution)
        height = int((board_bounds['max_y'] - board_bounds['min_y']) / resolution)
        
        # Create grid on GPU if available
        grid = self.device.zeros((height, width), dtype=self.device.int32)
        return grid, width, height, resolution
        
    def gpu_pathfind(self, grid, start, end):
        """GPU-accelerated A* pathfinding"""
        if not GPU_AVAILABLE:
            return self.cpu_pathfind(grid, start, end)
            
        # Simplified GPU pathfinding using wave propagation
        height, width = grid.shape
        distance_map = cp.full((height, width), cp.inf, dtype=cp.float32)
        distance_map[start[1], start[0]] = 0
        
        # Wave propagation on GPU
        for iteration in range(max(width, height)):
            old_map = distance_map.copy()
            
            # Propagate distances to neighbors
            for dy in [-1, 0, 1]:
                for dx in [-1, 0, 1]:
                    if dx == 0 and dy == 0:
                        continue
                        
                    shifted = cp.roll(cp.roll(distance_map, dx, axis=1), dy, axis=0)
                    cost = 1.0 if abs(dx) + abs(dy) == 1 else 1.414  # Manhattan vs diagonal
                    
                    # Update distances where improvement is possible
                    mask = (grid == 0) & (shifted + cost < distance_map)
                    distance_map = cp.where(mask, shifted + cost, distance_map)
            
            # Check convergence
            if cp.allclose(old_map, distance_map):
                break
                
        # Reconstruct path from end to start
        path = []
        current = end
        
        while current != start:
            path.append(current)
            x, y = current
            
            # Find neighbor with minimum distance
            min_dist = float('inf')
            next_pos = current
            
            for dy in [-1, 0, 1]:
                for dx in [-1, 0, 1]:
                    if dx == 0 and dy == 0:
                        continue
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < width and 0 <= ny < height:
                        if distance_map[ny, nx] < min_dist:
                            min_dist = distance_map[ny, nx]
                            next_pos = (nx, ny)
            
            current = next_pos
            
        path.append(start)
        path.reverse()
        
        # Convert back to CPU if needed
        if GPU_AVAILABLE:
            return [(int(x), int(y)) for x, y in path]
        return path
        
    def cpu_pathfind(self, grid, start, end):
        """CPU fallback pathfinding"""
        # Simple A* implementation
        from heapq import heappush, heappop
        
        height, width = grid.shape
        open_set = [(0, start)]
        came_from = {}
        g_score = {start: 0}
        f_score = {start: self.heuristic(start, end)}
        
        while open_set:
            current = heappop(open_set)[1]
            
            if current == end:
                # Reconstruct path
                path = []
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                path.append(start)
                return path[::-1]
            
            x, y = current
            for dx, dy in [(-1,0), (1,0), (0,-1), (0,1), (-1,-1), (-1,1), (1,-1), (1,1)]:
                neighbor = (x + dx, y + dy)
                nx, ny = neighbor
                
                if not (0 <= nx < width and 0 <= ny < height):
                    continue
                if grid[ny, nx] != 0:  # Obstacle
                    continue
                    
                tentative_g = g_score[current] + (1.414 if abs(dx) + abs(dy) == 2 else 1.0)
                
                if neighbor not in g_score or tentative_g < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f_score[neighbor] = tentative_g + self.heuristic(neighbor, end)
                    heappush(open_set, (f_score[neighbor], neighbor))
        
        return []  # No path found
        
    def heuristic(self, a, b):
        """Manhattan distance heuristic"""
        return abs(a[0] - b[0]) + abs(a[1] - b[1])
        
    def route_tracks(self, routing_data):
        """Main routing function"""
        results = []
        
        for connection in routing_data.get('connections', []):
            start_pad = connection['start']
            end_pad = connection['end']
            
            # Convert pad positions to grid coordinates
            start_grid = self.world_to_grid(start_pad['position'])
            end_grid = self.world_to_grid(end_pad['position'])
            
            # Find path using GPU acceleration
            path = self.gpu_pathfind(self.routing_grid, start_grid, end_grid)
            
            if path:
                # Convert grid path back to world coordinates
                world_path = [self.grid_to_world(pos) for pos in path]
                results.append({
                    'net': connection['net'],
                    'path': world_path,
                    'success': True
                })
            else:
                results.append({
                    'net': connection['net'],
                    'path': [],
                    'success': False
                })
                
        return results
        
    def world_to_grid(self, world_pos):
        """Convert world coordinates to grid coordinates"""
        if not hasattr(self, 'grid_resolution'):
            return (0, 0)
        x = int((world_pos['x'] - self.board_bounds['min_x']) / self.grid_resolution)
        y = int((world_pos['y'] - self.board_bounds['min_y']) / self.grid_resolution)
        return (x, y)
        
    def grid_to_world(self, grid_pos):
        """Convert grid coordinates to world coordinates"""
        if not hasattr(self, 'grid_resolution'):
            return {'x': 0, 'y': 0}
        x = grid_pos[0] * self.grid_resolution + self.board_bounds['min_x']
        y = grid_pos[1] * self.grid_resolution + self.board_bounds['min_y']
        return {'x': x, 'y': y}

class KiCadIPC:
    """IPC communication with KiCad"""
    
    def __init__(self):
        self.process = None
        self.router = GPURouter()
        
    def connect_to_kicad(self):
        """Connect to KiCad via subprocess IPC"""
        if KICAD_PYTHON_AVAILABLE:
            return self.connect_via_library()
        else:
            return self.connect_via_subprocess()
            
    def connect_via_library(self):
        """Connect using kicad-python library"""
        try:
            self.connection = KiCadConnection()
            return True
        except Exception as e:
            print(f"Failed to connect via kicad-python: {e}")
            return False
            
    def connect_via_subprocess(self):
        """Connect using subprocess IPC"""
        try:
            # Start a simple IPC server
            script_path = Path(__file__).parent / "ipc_server.py"
            if not script_path.exists():
                self.create_ipc_server(script_path)
                
            self.process = subprocess.Popen([
                sys.executable, str(script_path)
            ], stdin=subprocess.PIPE, stdout=subprocess.PIPE, 
               stderr=subprocess.PIPE, text=True)
            
            return True
        except Exception as e:
            print(f"Failed to start IPC server: {e}")
            return False
            
    def create_ipc_server(self, script_path):
        """Create a simple IPC server script"""
        ipc_server_code = '''
import sys
import json

def handle_request(request):
    """Handle IPC requests"""
    try:
        data = json.loads(request)
        command = data.get('command')
        
        if command == 'get_board_info':
            return {
                'bounds': {'min_x': 0, 'max_x': 100, 'min_y': 0, 'max_y': 100},
                'components': [],
                'nets': []
            }
        elif command == 'create_track':
            return {'success': True, 'track_id': 'track_123'}
        else:
            return {'error': f'Unknown command: {command}'}
            
    except Exception as e:
        return {'error': str(e)}

def main():
    """Main IPC loop"""
    while True:
        try:
            line = sys.stdin.readline()
            if not line:
                break
                
            response = handle_request(line.strip())
            print(json.dumps(response))
            sys.stdout.flush()
            
        except KeyboardInterrupt:
            break
        except Exception as e:
            print(json.dumps({'error': str(e)}))
            sys.stdout.flush()

if __name__ == '__main__':
    main()
'''
        with open(script_path, 'w') as f:
            f.write(ipc_server_code)
            
    def send_command(self, command, data=None):
        """Send command via IPC"""
        request = {'command': command}
        if data:
            request.update(data)
            
        if hasattr(self, 'connection'):
            # Use kicad-python library
            return self.connection.send_command(request)
        elif self.process:
            # Use subprocess IPC
            self.process.stdin.write(json.dumps(request) + '\n')
            self.process.stdin.flush()
            
            response = self.process.stdout.readline()
            return json.loads(response) if response else None
        else:
            return None
            
    def get_board_info(self):
        """Get board information from KiCad"""
        return self.send_command('get_board_info')
        
    def create_track(self, path, net_name, layer='F.Cu'):
        """Create a track in KiCad"""
        return self.send_command('create_track', {
            'path': path,
            'net': net_name,
            'layer': layer
        })

def orthoroute_action():
    """Main plugin action - called when toolbar button is clicked"""
    print("OrthoRoute GPU: Starting autorouting...")
    
    # Create IPC connection
    ipc = KiCadIPC()
    if not ipc.connect_to_kicad():
        print("Failed to connect to KiCad")
        return
        
    try:
        # Get board information
        board_info = ipc.get_board_info()
        if not board_info:
            print("Failed to get board information")
            return
            
        print(f"Board bounds: {board_info.get('bounds', {})}")
        
        # Set up routing grid
        bounds = board_info.get('bounds', {})
        ipc.router.board_bounds = bounds
        grid, width, height, resolution = ipc.router.create_routing_grid(bounds)
        ipc.router.routing_grid = grid
        ipc.router.grid_resolution = resolution
        
        # Mock routing data for demonstration
        routing_data = {
            'connections': [
                {
                    'net': 'GND',
                    'start': {'position': {'x': 10, 'y': 10}},
                    'end': {'position': {'x': 50, 'y': 50}}
                },
                {
                    'net': 'VCC',
                    'start': {'position': {'x': 20, 'y': 20}},
                    'end': {'position': {'x': 80, 'y': 30}}
                }
            ]
        }
        
        # Perform GPU-accelerated routing
        print("Running GPU-accelerated routing...")
        start_time = time.time()
        results = ipc.router.route_tracks(routing_data)
        end_time = time.time()
        
        print(f"Routing completed in {end_time - start_time:.3f} seconds")
        print(f"GPU acceleration: {'Enabled' if GPU_AVAILABLE else 'Disabled'}")
        
        # Create tracks in KiCad
        for result in results:
            if result['success'] and result['path']:
                track_result = ipc.create_track(result['path'], result['net'])
                if track_result and track_result.get('success'):
                    print(f"Created track for net {result['net']}")
                else:
                    print(f"Failed to create track for net {result['net']}")
            else:
                print(f"No path found for net {result['net']}")
                
        print("OrthoRoute GPU: Autorouting completed!")
        
    except Exception as e:
        print(f"Error during routing: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Cleanup
        if hasattr(ipc, 'process') and ipc.process:
            ipc.process.terminate()

# Plugin entry point for KiCad PCM
def main():
    """Plugin main entry point"""
    orthoroute_action()

if __name__ == "__main__":
    main()
