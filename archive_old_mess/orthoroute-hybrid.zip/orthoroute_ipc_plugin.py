#!/usr/bin/env python3
"""
OrthoRoute IPC Plugin - Properly Structured for KiCad 9.0+ IPC API
Entry point for the OrthoRoute GPU-accelerated autorouter
"""

import os
import sys
import json
import tempfile
import time
import subprocess
import traceback
from pathlib import Path

def log_message(message):
    """Log messages with timestamp"""
    timestamp = time.strftime("%H:%M:%S")
    print(f"[{timestamp}] {message}")

# Import KiCad IPC API
try:
    from kipy import KiCad
    from kipy.board import Board
    from kipy.board_types import Track, Net, Via
    from kipy.util.units import to_mm, from_mm
    from kipy.geometry import Vector2
    IPC_AVAILABLE = True
    log_message("✅ KiCad IPC API (kipy) imported successfully")
except ImportError as e:
    log_message(f"❌ Failed to import KiCad IPC API: {e}")
    log_message("Please install: pip install kicad-python")
    IPC_AVAILABLE = False

class OrthoRouteIPCPlugin:
    """OrthoRoute IPC Plugin Class - KiCad 9.0+ Style"""
    
    def __init__(self):
        """Initialize the plugin"""
        self.kicad = None
        self.board = None
        
    def connect_to_kicad(self):
        """Connect to KiCad via IPC API"""
        if not IPC_AVAILABLE:
            log_message("❌ KiCad IPC API not available")
            return False
            
        try:
            # Get connection info from environment variables set by KiCad
            api_socket = os.environ.get('KICAD_API_SOCKET')
            api_token = os.environ.get('KICAD_API_TOKEN')
            
            log_message(f"API Socket: {api_socket}")
            log_message(f"API Token: {'***' if api_token else 'None'}")
            
            # If environment variables aren't set, try to find the socket manually
            if not api_socket or not api_token:
                log_message("⚠️  Environment variables not set, attempting manual connection...")
                api_socket, api_token = self.find_kicad_api_socket()
            
            if not api_socket:
                log_message("❌ Could not find KiCad API connection info")
                log_message("Make sure KiCad's IPC API is enabled in preferences")
                return False
            
            # Connect to KiCad via IPC API
            log_message("🔌 Connecting to KiCad...")
            
            # Handle the ipc:// prefix if present
            socket_path = api_socket
            if socket_path.startswith('ipc://'):
                socket_path = socket_path[6:]  # Remove ipc:// prefix
            
            log_message(f"Using socket path: {socket_path}")
            self.kicad = KiCad(socket_path=socket_path, token=api_token)
            
            return True
            
        except Exception as e:
            log_message(f"❌ Error connecting to KiCad: {e}")
            traceback.print_exc()
            return False
    
    def find_kicad_api_socket(self):
        """Try to find KiCad's API socket manually"""
        log_message("🔍 Searching for KiCad API socket...")
        
        # First try the specific path mentioned by the user
        user_socket = Path(r"C:\Users\Benchoff\AppData\Local\Temp\kicad\api.sock")
        if user_socket.exists():
            log_message(f"✅ Found socket at user-specified path: {user_socket}")
            return str(user_socket), ""
        
        # Common socket locations
        temp_dir = Path(tempfile.gettempdir())
        possible_paths = [
            temp_dir / "kicad" / "api.sock",
            temp_dir / "api.sock",
        ]
        
        # Look for socket files with PID suffix
        kicad_temp = temp_dir / "kicad"
        if kicad_temp.exists():
            for file in kicad_temp.glob("api*.sock"):
                possible_paths.append(file)
        
        # Try to find any socket file in temp
        for file in temp_dir.glob("**/api*.sock"):
            possible_paths.append(file)
        
        for socket_path in possible_paths:
            if socket_path.exists():
                log_message(f"✅ Found socket at: {socket_path}")
                # For manual connection, we don't have a token, so try empty string
                return str(socket_path), ""
        
        log_message("❌ No KiCad API socket found")
        return None, None
    
    def get_board_info(self):
        """Get board information"""
        try:
            # Get the active board
            log_message("📋 Getting active board...")
            self.board = self.kicad.get_board()
            if not self.board:
                log_message("❌ No active board found")
                return False
                
            # Get board info
            bbox = self.board.get_bounding_box()
            width_mm = to_mm(bbox.width)
            height_mm = to_mm(bbox.height)
            
            # Count nets
            nets = self.board.get_nets()
            net_count = len([net for net in nets if net.name and net.name.strip()])
            
            log_message(f"📏 Board: {width_mm:.1f} × {height_mm:.1f} mm")
            log_message(f"🔗 Nets: {net_count}")
            
            return True
            
        except Exception as e:
            log_message(f"❌ Error getting board info: {e}")
            traceback.print_exc()
            return False
    
    def run_routing(self):
        """Run the main routing algorithm"""
        try:
            log_message("🚀 Starting OrthoRoute routing process...")
            
            # Get board info
            if not self.get_board_info():
                return False
            
            # Create routing request
            nets = self.board.get_nets()
            routing_request = {
                "board_info": {
                    "width_mm": to_mm(self.board.get_bounding_box().width),
                    "height_mm": to_mm(self.board.get_bounding_box().height),
                    "net_count": len([net for net in nets if net.name and net.name.strip()])
                },
                "nets": []
            }
            
            # Add net information
            for net in nets:
                if net.name and net.name.strip():
                    net_info = {
                        "name": net.name,
                        "id": net.net_id if hasattr(net, 'net_id') else 0,
                        "pads": []
                    }
                    routing_request["nets"].append(net_info)
            
            log_message(f"✅ Prepared routing request for {len(routing_request['nets'])} nets")
            
            # For now, just show the info - actual routing would launch the standalone server
            log_message("🎯 OrthoRoute IPC Plugin executed successfully!")
            log_message("📊 Board analysis complete")
            
            # Future: Launch standalone routing server and process results
            # self.launch_routing_server(routing_request)
            
            return True
            
        except Exception as e:
            log_message(f"❌ Error in routing process: {e}")
            traceback.print_exc()
            return False

    def run(self):
        """Main plugin execution method - IPC Plugin Pattern"""
        log_message("🚀 OrthoRoute IPC Plugin Starting...")
        
        # Check if IPC API is available
        if not IPC_AVAILABLE:
            log_message("❌ KiCad IPC API (kipy) not available")
            log_message("Please install: pip install kicad-python")
            log_message("Plugin cannot run without IPC API support")
            return 1
        
        # Connect to KiCad
        if not self.connect_to_kicad():
            log_message("❌ Failed to connect to KiCad")
            return 1
        
        # Run the routing process
        if not self.run_routing():
            log_message("❌ Routing process failed")
            return 1
        
        log_message("✅ OrthoRoute plugin completed successfully")
        return 0

    def launch_routing_server(self, routing_request):
        """Launch the standalone routing server (future implementation)"""
        # This would launch orthoroute_standalone_server.py with the routing request
        pass

# IPC Plugin Pattern - Direct instantiation and execution
if __name__ == "__main__":
    try:
        plugin = OrthoRouteIPCPlugin()
        exit_code = plugin.run()
        log_message(f"🏁 Plugin finished with exit code: {exit_code}")
        # Don't call sys.exit() - this can kill KiCad if run in plugin context
    except Exception as e:
        log_message(f"❌ Fatal error in OrthoRoute IPC Plugin: {e}")
        traceback.print_exc()
        # Don't call sys.exit() - this can kill KiCad
