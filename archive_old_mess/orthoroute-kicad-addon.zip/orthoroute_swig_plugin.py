#!/usr/bin/env python3
"""
OrthoRoute SWIG Plugin - Compatible with KiCad 9.0
Traditional SWIG-based plugin for maximum compatibility
"""

import os
import sys
import time
import traceback

def log_message(message):
    """Log messages with timestamp"""
    timestamp = time.strftime("%H:%M:%S")
    print(f"[{timestamp}] {message}")

# Import KiCad SWIG API
try:
    import pcbnew
    from pcbnew import wxPointMM, FromMM, ToMM, TRACK
    SWIG_API_AVAILABLE = True
    log_message("✅ KiCad SWIG API imported successfully")
except ImportError as e:
    log_message(f"❌ Failed to import KiCad SWIG API: {e}")
    SWIG_API_AVAILABLE = False

class OrthoRouteSWIGPlugin(pcbnew.ActionPlugin):
    """Traditional KiCad ActionPlugin using SWIG API"""

    def defaults(self):
        """Set default plugin properties"""
        self.name = "OrthoRoute GPU Autorouter"
        self.category = "Routing"
        self.description = "High-performance GPU-accelerated autorouter"
        self.show_toolbar_button = True
        self.icon_file_name = os.path.join(os.path.dirname(__file__), "resources", "icon.png")

    def Run(self):
        """Main plugin execution method"""
        try:
            log_message("🚀 Starting OrthoRoute GPU Autorouter...")
            
            # Get the current board
            board = pcbnew.GetBoard()
            if not board:
                log_message("❌ No board found")
                self.show_message("No board is currently open", "Error")
                return
            
            log_message(f"📋 Board loaded: {board.GetFileName()}")
            
            # Create a simple test track to verify plugin is working
            self.create_test_track(board)
            
            # Refresh the display
            pcbnew.Refresh()
            
            log_message("✅ OrthoRoute plugin completed successfully")
            self.show_message("OrthoRoute plugin executed successfully!\nCreated test track.", "Success")
            
        except Exception as e:
            error_msg = f"❌ Error in OrthoRoute plugin: {e}"
            log_message(error_msg)
            traceback.print_exc()
            self.show_message(f"Plugin error: {e}", "Error")

    def create_test_track(self, board):
        """Create a test track to verify the plugin is working"""
        try:
            log_message("🔧 Creating test track...")
            
            # Get board dimensions
            bounding_box = board.ComputeBoundingBox()
            start_x = bounding_box.GetX() + FromMM(10)  # 10mm from left edge
            start_y = bounding_box.GetY() + FromMM(10)  # 10mm from top edge
            
            # Create a simple test track
            track = pcbnew.PCB_TRACK(board)
            track.SetStart(pcbnew.wxPoint(start_x, start_y))
            track.SetEnd(pcbnew.wxPoint(start_x + FromMM(20), start_y))  # 20mm long
            track.SetWidth(FromMM(0.2))  # 0.2mm width
            track.SetLayer(pcbnew.F_Cu)  # Front copper layer
            
            # Add the track to the board
            board.Add(track)
            
            log_message(f"✅ Test track created: {ToMM(track.GetLength()):.1f}mm long")
            
        except Exception as e:
            log_message(f"❌ Failed to create test track: {e}")
            raise

    def show_message(self, message, title="OrthoRoute"):
        """Show a message dialog to the user"""
        try:
            import wx
            dlg = wx.MessageDialog(None, message, title, wx.OK | wx.ICON_INFORMATION)
            dlg.ShowModal()
            dlg.Destroy()
        except:
            # Fallback to console output if wx is not available
            log_message(f"{title}: {message}")

# This plugin will be discovered and loaded by KiCad's PCM system
# No explicit registration needed for PCM plugins
