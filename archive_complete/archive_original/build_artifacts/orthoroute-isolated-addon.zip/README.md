# OrthoRoute Isolated - Crash-Safe GPU Routing

## 🎯 PROBLEM SOLVED: No More KiCad Crashes!

This version of OrthoRoute uses **complete process isolation** to prevent KiCad crashes. The GPU routing engine runs in a completely separate process and communicates with KiCad through file-based messaging.

## ✅ Key Features

- **🛡️ Crash Protection**: GPU operations run in isolated process
- **🚀 High Performance**: GPU-accelerated routing algorithms  
- **📊 Real-time Progress**: Live progress monitoring with cancel support
- **🔄 File-based Communication**: Robust inter-process communication
- **🧹 Clean Shutdown**: Proper resource cleanup and memory management

## 🔧 How It Works

1. **KiCad Plugin**: Lightweight plugin extracts board data
2. **Standalone Server**: GPU routing runs in separate Python process
3. **File Communication**: JSON-based request/response messaging
4. **Result Integration**: Routed tracks applied back to KiCad board

## 🚀 Installation

1. Open KiCad
2. Go to **Tools → Plugin and Content Manager**
3. Click **Install from File**
4. Select: `orthoroute-isolated-addon.zip`

## 💡 Benefits of Process Isolation

- ✅ **No KiCad crashes** - GPU issues cannot affect KiCad
- ✅ **Independent memory** - Separate process memory space
- ✅ **Clean GPU shutdown** - Proper CUDA cleanup on completion
- ✅ **Error isolation** - GPU errors don't crash KiCad
- ✅ **Progress monitoring** - Real-time status without blocking KiCad

## 🔬 Technical Details

### Architecture
```
KiCad Process          │  Isolated GPU Process
                      │
Plugin.py             │  orthoroute_standalone_server.py
├─ Extract board data │  ├─ Load GPU modules (CuPy/CUDA)
├─ Start GPU server   │  ├─ Initialize routing engine
├─ Send request       │  ├─ Process routing request
├─ Monitor progress   │  ├─ GPU wave routing
└─ Apply results      │  └─ Return results + cleanup
```

### Communication Protocol
- **Request**: `routing_request.json` - Board data and configuration
- **Status**: `routing_status.json` - Real-time progress updates
- **Result**: `routing_result.json` - Routing results and statistics
- **Control**: `shutdown.flag` - Clean server shutdown

This approach ensures that even if the GPU process crashes or hangs, KiCad remains completely stable and responsive.
